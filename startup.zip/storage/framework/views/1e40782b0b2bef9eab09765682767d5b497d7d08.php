  <?php $__env->startSection('title', 'Legal IT'); ?>

  <?php $__env->startSection('css'); ?>

  <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content_header'); ?>
      <div>
        <h3><a href='home' ><img class="push-left" src="dist/img/openlaw-dark.png" height="50"></a>
          ADMIN DASHBOARD
          <small> Law Office Software</small>
        </h3></div>
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  'You're login as ADMIN

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>