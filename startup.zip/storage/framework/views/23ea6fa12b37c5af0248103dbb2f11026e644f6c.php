<?php $__env->startSection('title', 'Legal IT'); ?>

<?php $__env->startSection('css'); ?>

<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_header'); ?>
<div><h3><a href='home' ><img class="push-left" src="dist/img/openlaw-dark.png" height="50"></a>
  Dashboard
  <small>Control panel</small>
</h3>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials._dataperkara', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="row">
  <div class="col-lg-6 col-md-6 col-sm-12">
    <?php echo $__env->make('partials._3dpiedonut', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
  <div class="col-lg-6 col-md-6 col-sm-12">
    <?php echo $__env->make('partials._3dbubble', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</div>
</div>
<div class="row">
<div class="col-md-6">
  <?php echo $__env->make('partials._pemulihanaset', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<div class="col-lg-6 col-md-6 col-sm-12">
    <?php echo $__env->make('partials._kerugiannegara', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>