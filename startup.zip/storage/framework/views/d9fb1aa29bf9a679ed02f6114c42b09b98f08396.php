<?php echo $__env->make('admin.settings', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php $__env->startSection('bcrumb', 'page_header'); ?>

		<?php $__env->startSection('judul':: ); ?>

	<?php $__env->startSection('template'); ?>
		'WELCOME'
	<?php $__env->stopSection(); ?>
				

