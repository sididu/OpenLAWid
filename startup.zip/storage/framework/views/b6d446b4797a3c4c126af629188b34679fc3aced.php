  <?php $__env->startSection('title', 'Legal IT'); ?>

  <?php $__env->startSection('css'); ?>

  <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content_header'); ?>
      <div>
        
        <h3><a href='home' ><img class="push-left" src="dist/img/openlaw-dark.png" height="50"></a>
          Legal IT
          <small> Law Office Software</small>
        </h3>
        </div>                            
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="box">
            <div class="box-header">
              <h3 class="box-title text-uppercase">Daftar Penyidikan Umum [rp3mum]</h3>

              <div class="box-tools">
                <div class="input-group input-group-sm" style="width: 150px;">
                  <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">

                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped">
                <tbody><tr>
                  <th>Kasus</th>
                </tr>
                <tr>
                  <td>
                  <?php echo $__env->make('partials._kasusrp3muma', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  </td>
                </tr>
                <tr>
                  <td>
                  <?php echo $__env->make('partials._kasusrp3mumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  </td>
                </tr>
                <tr>
                  <td>
                  <?php echo $__env->make('partials._kasusrp3mumc', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  </td>
                </tr>
                <tr>
                  <td>
                  <?php echo $__env->make('partials._kasusrp3mumd', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  </td>
                </tr>
              </tbody></table>
            </div>
            <!-- /.box-body -->
          </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>