<?php $__env->startSection('title', 'Kejaksaan'); ?>

<?php $__env->startSection('content_header'); ?>
<h1><a href='home' ><img class="push-left" src="../dist/img/logo-kejaksaan.png" width="75"></a>
  Dashboard
  <small>Register Perkara Baru [rp1]</small>
</h1>
<ol class="breadcrumb">
  <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
  <li class="active">Dashboard</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

'Page Register Perkara Baru [rp1]'
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>