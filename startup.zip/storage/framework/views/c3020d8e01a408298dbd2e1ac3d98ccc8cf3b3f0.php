  <?php $__env->startSection('title', 'Kejaksaan'); ?>

  <?php $__env->startSection('css'); ?>

  <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content_header'); ?>
      <div>
        <h3><a href='home' ><img class="push-left" src="dist/img/logo-kejaksaan.png" width="75"></a>
          Direktorat Penyidikan
          <small> Tindak Pidana Khusus</small>
        </h3></div>
      <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
          <li class="active"><?php echo $__env->yieldContent('judul_breadcrumb'); ?></li>
      </ol>
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="box box-default">
  <div class="box-header with-border">
    <h3 class="box-title"><?php echo $__env->yieldContent('judul'); ?></h3>
  </div>
  <div class="container">
  <?php echo $__env->yieldContent('template'); ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>