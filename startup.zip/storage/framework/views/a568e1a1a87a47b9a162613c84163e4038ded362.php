	<?php $__env->startSection('title', 'Kejaksaan'); ?>

		<?php $__env->startSection('content_header'); ?>

		<h1><a href='home' ><img class="push-left" src="dist/img/logo-kejaksaan.png" width="100"></a>

		DIR. PENYELIDIKAN & PENYIDIKAN 
		
		<small>Control panel</small></h1>

		<?php $__env->stopSection(); ?>


			<?php echo $__env->yieldContent('content'); ?>
			

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>