	<?php $__env->startSection('title', 'Kejaksaan'); ?>

	<?php $__env->startSection('css'); ?>

	<?php $__env->stopSection(); ?>

		<?php $__env->startSection('content_header'); ?>
			<div>
				<h3><a href='home' ><img class="push-left" src="dist/img/logo-kejaksaan.png" width="75"></a>
				  Direktorat Penyidikan
				  <small> Tindak Pidana Khusus</small>
				</h3>
			</div>
		<?php $__env->stopSection(); ?>

			<?php $__env->startSection('content'); ?>

			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">DAFTAR BENDA SITAAN</h3>				
				</div>
				<div class="box-body">
					<?php echo $__env->make('partials._bendasitaan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>

		<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>