</h1>
<ol class="breadcrumb">
  <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li> <li class="active">Dashboard</li>
</ol>
</section>
<div class="box box-default">
  <div class="box-header with-border">
    <h3 class="box-title">PERKARA PENYELIDIKAN</h3>
    <div class="box-tools pull-right">
      <a href="dp_kasus_baru.php" class="btn btn-app btn-xs"><span class="badge bg-yellow">3</span><i class="fa fa-list-ul"></i> RP-1</a>
      <a href="dp_penyelidikan.php" class="btn btn-app btn-xs"><span class="badge bg-yellow">3</span><i class="fa fa-list-ul"></i>RP-2</a>
      <a href="dp_penyidikan_umum.php" class="btn btn-app btn-xs"><span class="badge bg-yellow">3</span><i class="fa fa-list-ul"></i>RP-3MUM</a>
      <a href="dp_penyidikan_khusus.php" class="btn btn-app btn-xs"><span class="badge bg-yellow">3</span><i class="fa fa-list-ul"></i>RP-3SUS</a>
      <a href="dp_status_subyek.php" class="btn btn-app btn-xs"><span class="badge bg-yellow">9</span><i class="fa fa-user"></i>Tahanan</a>
  </div>
</div>