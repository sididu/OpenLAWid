<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0.0
    </div>
    <small>Copyright © 2014-2016 <a href="http://soerojo.com" target="_blank">Tonny Soerojo &amp; Rekan</a>. All rights reserved.</small> 
  </footer>