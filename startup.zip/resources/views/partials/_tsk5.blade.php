<div class="medi col-md-12a"> 
<div class="btn-group-vertical btn-group-xs pull-right" role="group" aria-label="...">
  <a href='frt1' class="btn btn-default"> TSK &nbsp;<i class="glyphicon glyphicon-log-in"></i></a>
  <a href='frt2' class="btn btn-danger">  TAHAN &nbsp;<i class="glyphicon glyphicon-log-in"></i></a>
</div>
</div>
<div class="media-left"> <a href="#"> <img alt="64x64" class="media-object" data-src="holder.js/64x64" src="dist/img/subyek/robert.jpg" data-holder-rendered="true" style="width: 64px; height: 64px;"> </a> </div> <div class="media-body"> <strong class="media-heading">Tersangka #5</strong> Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. 
</div> 
</div>