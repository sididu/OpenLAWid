 <!-- ======================================== -->

<?php
<!-- Small boxes (Stat box) -->
 <div class="box-body">
  <div class="row">
  <div class="col-md-3 col-xs-6">
      <!-- small box -->
      echo "COLUMN 1";
    </div>
    <!-- ./col -->
    <div class="col-md-3 col-xs-6">
      <!-- small box -->
      echo "COLUMN 2";
    </div>
    <!-- ./col -->
    <div class="col-md-3 col-xs-6">
      <!-- small box -->
      echo "COLUMN 3";
    </div>
    <!-- ./col -->
    <div class="col-md-3 col-xs-6">
      <!-- small box -->
      echo "COLUMN 4";
    </div>
    <!-- ./col -->
  </div>
  <!-- /.row -->
<!-- ./box-body-->
?>