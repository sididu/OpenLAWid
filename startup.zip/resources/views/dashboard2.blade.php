@include('admin.settings')

	@section('bcrumb', 'page_header')

		@section('judul':: )

	@section('template')
		'WELCOME'
	@endsection
				

