@extends('adminlte::page')

@section('title', 'Legal IT')

@section('content_header')
<div><h3><a href='home' ><img class="push-left" src="dist/img/openlaw-dark.png" height="50"></a>
  Dashboard
  <small>Register Perkara [rp0]</small>
</h3>
</div>
<ol class="breadcrumb">
  <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
  <li class="active">Perkara [rp0]</li>
</ol>
@stop

@section('content')


@stop